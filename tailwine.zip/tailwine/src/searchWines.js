import { database } from './app.js';

function searchWines() {
    console.log("searchWines function called from searchWines.js");
    var searchTerm = document.getElementById("searchInput").value.toLowerCase();

    // Use the 'searchName' attribute for searching
    database.ref('Wines').orderByChild('searchName').startAt(searchTerm).endAt(searchTerm + "\uf8ff").once('value').then(snapshot => {
        let winesByName = snapshot.val();
        console.log("Fetched wines:", winesByName);  // Log the fetched data
        if (winesByName) {
            displayResults(Object.values(winesByName));
        } else {
            console.log("No wines found for the search term:", searchTerm);
        }
    }).catch(error => {
        console.error("Error fetching wines by searchName:", error);
    });
}
function filterWines(wines, searchTerm) {
    const results = [];
    for (const wineKey in wines) {
        const wine = wines[wineKey];
        const wineName = wine.Name.toLowerCase();
        const wineCode = wine.code?.toString() || "";

        if (wineName.includes(searchTerm) || wineCode.includes(searchTerm)) {
            results.push(wine);
        }
    }
    return results;
}

function displayResults(filteredWines) {
    const resultsDiv = document.getElementById("results");
    resultsDiv.innerHTML = "";  // Clear previous results

    for (const wine of filteredWines) {
        const card = document.createElement("div");
        card.className = "card";
        card.style.backgroundImage = `url(${wine.image_url})`; // Set the wine image as the card's background

        const cardContent = document.createElement("div");
        cardContent.className = "card__content";

        const cardTitle = document.createElement("h2");
        cardTitle.className = "card__title";
        cardTitle.textContent = wine.Name;
        cardContent.appendChild(cardTitle);

        

        const cardSubtitle = document.createElement("p");
        cardSubtitle.className = "card__subtitle";
        cardSubtitle.textContent = `Region: ${wine.Region} | Grape: ${wine.Grape} | Vintage: ${wine.Vintage}`;
        cardContent.appendChild(cardSubtitle);

        const cardCode = document.createElement("p");
        cardCode.className = "card__indicator";
        cardCode.textContent = `Code: ${wine.code}`;
        cardContent.appendChild(cardCode);

        card.appendChild(cardContent);
        resultsDiv.appendChild(card);
    }
}





export { searchWines, filterWines, displayResults };
