// Firebase configuration and initialization
const firebaseConfig = {
    apiKey: "AIzaSyC_zxy7F3oJ6QdJCzyZ7XYBD3CuONWq5Zg",
    authDomain: "wine-syndicate.firebaseapp.com",
    databaseURL: "https://wine-syndicate-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "wine-syndicate",
    storageBucket: "wine-syndicate.appspot.com",
    messagingSenderId: "522379106516",
    appId: "1:522379106516:web:e357926c00d2f4947dc341",
    measurementId: "G-1MY5CE72B3"
};
firebase.initializeApp(firebaseConfig);
console.log("Firebase initialized");

// Exported functions and variables
import { searchWines } from './searchWines.js';

function initiateSearch() {
    console.log("initiateSearch function called from app.js");
    searchWines();
}

export const database = firebase.database();
window.initiateSearch = initiateSearch;  // Make the function globally accessible

function setupApp() {
    console.log("Setting up app...");

    const searchButton = document.querySelector("button");
    const searchInput = document.querySelector("#searchInput"); // Select the search input by its ID

    if (searchButton) {
        searchButton.addEventListener("click", function() {
            console.log("Search button clicked");
            initiateSearch();
        });
    } else {
        console.error("Search button not found!");
    }

    // Add event listener for Enter key on the search input
    if (searchInput) {
        searchInput.addEventListener("keydown", function(event) {
            if (event.key === "Enter") {
                event.preventDefault(); // Prevent the default form submission
                searchButton.click();  // Programmatically click the search button
            }
        });
    } else {
        console.error("Search input not found!");
    }
}

// Ensure the DOM is fully loaded before setting up the app
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", setupApp);
} else {
    setupApp();
}